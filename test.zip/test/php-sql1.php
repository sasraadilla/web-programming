<head>
	<title>Tes Latihan Penggunaan Query SQL Web PHP</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<h3>Latihan Penggunaan Query SQL Web PHP </h3>
<table>
    <tr>
        <th>No.</th>
        <th>NIM</th>
        <th>Nama</th>
        <th>Tempat Lahir</th>
        <th>Gender</th>
    </tr>
    <?php
    include 'koneksi.php';
    $sqlmhs = mysqli_query($koneksi, "select nim, nama, tlahir, gender  from mahasiswa");
    $no=1;
    foreach ($sqlmhs as $row) {
        echo "<tr>
            <td>$no</td>
            <td>".$row['nim']."</td>
            <td>".$row['nama']."</td>
            <td>".$row['tlahir']."</td>
            <td>".$row['gender']."</td>
         </tr>";
        $no++;
    }
    ?>
</table>