<?php 
    $server   = "localhost";    
    $database = "dblatihan1";
    $username = "indra4";
    $password = "indra4";

//$koneksi = mysqli_connect("localhost","root","root","dblatihan1");
//Nama  host  >> Localhost  UserDB  >> root  PassDB  >> root Nama-Database >> dblatihan1 
$koneksi = mysqli_connect($server,$username,$password,$database);
// Koneksi DB Check
    if (mysqli_connect_errno()){
	    echo "Error Masalah Koneksi Gagal : " . mysqli_connect_error();
    }  
 //  echo "Koneksi DB berhasil";
?>

